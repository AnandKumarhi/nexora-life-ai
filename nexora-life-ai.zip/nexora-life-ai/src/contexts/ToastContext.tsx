import React, { createContext, useCallback, useContext, useState } from 'react';
import { uid } from '../utils/helpers';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface ToastContextValue {
  toasts: Toast[];
  toast: (message: string, type?: Toast['type']) => void;
  dismiss: (id: string) => void;
}

const ToastContext = createContext<ToastContextValue>({
  toasts: [],
  toast: () => {},
  dismiss: () => {},
});

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const toast = useCallback((message: string, type: Toast['type'] = 'success') => {
    const id = uid();
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3500);
  }, []);

  const dismiss = useCallback((id: string) => {
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ toasts, toast, dismiss }}>
      {children}
      <ToastContainer toasts={toasts} dismiss={dismiss} />
    </ToastContext.Provider>
  );
};

export const useToast = () => useContext(ToastContext);

// ─── Toast UI ─────────────────────────────────────────────────────
const COLORS: Record<Toast['type'], string> = {
  success: '#22C55E',
  error: '#EF4444',
  info: '#3B82F6',
};

const ToastContainer: React.FC<{ toasts: Toast[]; dismiss: (id: string) => void }> = ({
  toasts,
  dismiss,
}) => (
  <div
    style={{
      position: 'fixed',
      top: 56,
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 9999,
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      width: '90%',
      maxWidth: 390,
      pointerEvents: 'none',
    }}
  >
    {toasts.map((t) => (
      <div
        key={t.id}
        onClick={() => dismiss(t.id)}
        className="scale-in"
        style={{
          background: '#1A1A24',
          border: `1px solid ${COLORS[t.type]}40`,
          borderLeft: `3px solid ${COLORS[t.type]}`,
          borderRadius: 14,
          padding: '12px 16px',
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          pointerEvents: 'all',
          cursor: 'pointer',
          boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
        }}
      >
        <span style={{ fontSize: 16 }}>
          {t.type === 'success' ? '✅' : t.type === 'error' ? '❌' : 'ℹ️'}
        </span>
        <span style={{ fontSize: 14, fontWeight: 500, color: '#fff', flex: 1 }}>
          {t.message}
        </span>
      </div>
    ))}
  </div>
);
