import React, { useState } from 'react';
import AppShell from '../components/layout/AppShell';
import { Card, Button, Input, Select, Modal, EmptyState, Badge } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useTasks } from '../hooks/useTasks';
import { Task, TaskCategory, TaskPriority } from '../utils/types';
import { getPriorityColor } from '../utils/helpers';

const CATEGORIES: TaskCategory[] = ['Work', 'Health', 'Personal', 'Learning', 'Finance'];
const PRIORITIES: TaskPriority[] = ['High', 'Medium', 'Low'];
const CAT_FILTERS = ['All', ...CATEGORIES];

interface TaskForm {
  title: string;
  category: TaskCategory;
  priority: TaskPriority;
  dueDate: string;
}

const defaultForm = (): TaskForm => ({
  title: '',
  category: 'Work',
  priority: 'Medium',
  dueDate: '',
});

const TasksPage: React.FC = () => {
  const { user } = useAuth();
  const { tasks, addTask, editTask, toggleTask, removeTask } = useTasks(user?.uid);

  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('All');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [form, setForm] = useState<TaskForm>(defaultForm());
  const [saving, setSaving] = useState(false);

  const filtered = tasks.filter((t) => {
    const matchSearch = t.title.toLowerCase().includes(search.toLowerCase());
    const matchCat = catFilter === 'All' || t.category === catFilter;
    return matchSearch && matchCat;
  });
  const active = filtered.filter((t) => !t.done);
  const done = filtered.filter((t) => t.done);

  const openAdd = () => {
    setEditingTask(null);
    setForm(defaultForm());
    setModalOpen(true);
  };

  const openEdit = (t: Task) => {
    setEditingTask(t);
    setForm({ title: t.title, category: t.category, priority: t.priority, dueDate: t.dueDate });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.title.trim()) return;
    setSaving(true);
    if (editingTask) {
      await editTask(editingTask.id, form);
    } else {
      await addTask(form);
    }
    setSaving(false);
    setModalOpen(false);
  };

  const stats = [
    { label: 'Total', val: tasks.length, color: '#3B82F6' },
    { label: 'Active', val: tasks.filter((t) => !t.done).length, color: '#F59E0B' },
    { label: 'Done', val: tasks.filter((t) => t.done).length, color: '#22C55E' },
  ];

  return (
    <AppShell>
      <div style={{ padding: '52px 20px 20px' }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <h2 style={{ fontSize: 28, fontWeight: 800, letterSpacing: -0.6 }}>Tasks</h2>
          <button
            onClick={openAdd}
            style={{
              width: 40, height: 40, borderRadius: 13,
              background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)',
              border: 'none', cursor: 'pointer', fontSize: 22,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >+</button>
        </div>

        {/* Search */}
        <div style={{ position: 'relative', marginBottom: 14 }}>
          <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', fontSize: 15 }}>🔍</span>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search tasks..."
            style={{
              background: '#1A1A24', border: '1px solid #2A2A38', borderRadius: 14,
              padding: '14px 18px 14px 42px', fontSize: 14, color: '#fff',
              fontFamily: 'Inter,sans-serif', outline: 'none', width: '100%',
            }}
          />
          {search && (
            <button onClick={() => setSearch('')} style={{
              position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
              background: 'none', border: 'none', color: '#8B8B9E', cursor: 'pointer', fontSize: 16,
            }}>✕</button>
          )}
        </div>

        {/* Category filter */}
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4, marginBottom: 20 }}>
          {CAT_FILTERS.map((c) => (
            <button
              key={c}
              onClick={() => setCatFilter(c)}
              style={{
                padding: '8px 16px', borderRadius: 100, whiteSpace: 'nowrap',
                background: catFilter === c ? '#3B82F6' : '#1A1A24',
                border: `1px solid ${catFilter === c ? '#3B82F6' : '#2A2A38'}`,
                color: catFilter === c ? '#fff' : '#8B8B9E',
                fontSize: 13, fontWeight: 500, cursor: 'pointer',
                fontFamily: 'Inter,sans-serif', transition: 'all 0.2s ease',
              }}
            >{c}</button>
          ))}
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, marginBottom: 24 }}>
          {stats.map((s) => (
            <Card key={s.label} style={{ textAlign: 'center', padding: '14px 8px' }}>
              <p style={{ fontSize: 22, fontWeight: 800, color: s.color }}>{s.val}</p>
              <p style={{ fontSize: 11, color: '#8B8B9E', marginTop: 2 }}>{s.label}</p>
            </Card>
          ))}
        </div>

        {tasks.length === 0 && (
          <EmptyState emoji="📋" title="No tasks yet" subtitle="Add your first task to start tracking your progress"
            action={{ label: 'Add First Task', onClick: openAdd }} />
        )}

        {/* Active */}
        {active.length > 0 && (
          <div style={{ marginBottom: 24 }}>
            <p style={{ fontSize: 12, color: '#8B8B9E', fontWeight: 600, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.8 }}>
              Active · {active.length}
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {active.map((t, i) => (
                <Card key={t.id} className="fade-up" style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12, animationDelay: `${i * 0.05}s` }}>
                  <button
                    onClick={() => toggleTask(t.id)}
                    style={{
                      width: 28, height: 28, borderRadius: 9, flexShrink: 0,
                      border: '2px solid #2A2A38', background: 'transparent',
                      cursor: 'pointer', transition: 'all 0.2s ease', fontSize: 12,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}
                  />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 14, fontWeight: 500, marginBottom: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.title}</p>
                    <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap', alignItems: 'center' }}>
                      <Badge color="#B0B0C3" bg="rgba(176,176,195,0.1)">{t.category}</Badge>
                      <Badge color={getPriorityColor(t.priority)} bg={`${getPriorityColor(t.priority)}18`}>
                        ● {t.priority}
                      </Badge>
                      {t.dueDate && <span style={{ fontSize: 11, color: '#8B8B9E' }}>📅 {t.dueDate}</span>}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 2 }}>
                    <button onClick={() => openEdit(t)} style={{ padding: 8, background: 'none', border: 'none', cursor: 'pointer', color: '#8B8B9E', fontSize: 15 }}>✏️</button>
                    <button onClick={() => removeTask(t.id)} style={{ padding: 8, background: 'none', border: 'none', cursor: 'pointer', color: '#EF4444', fontSize: 15 }}>🗑</button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Completed */}
        {done.length > 0 && (
          <div>
            <p style={{ fontSize: 12, color: '#8B8B9E', fontWeight: 600, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.8 }}>
              Completed · {done.length}
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {done.map((t) => (
                <Card key={t.id} style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, opacity: 0.5 }}>
                  <div style={{
                    width: 28, height: 28, borderRadius: 9, background: '#22C55E',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 13,
                  }}>✓</div>
                  <p style={{ fontSize: 14, textDecoration: 'line-through', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.title}</p>
                  <button onClick={() => removeTask(t.id)} style={{ padding: 6, background: 'none', border: 'none', cursor: 'pointer', color: '#EF4444', fontSize: 14 }}>🗑</button>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingTask ? 'Edit Task' : 'New Task'}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Input placeholder="Task title" value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} autoFocus />
          <Select label="Category" value={form.category}
            onChange={(e) => setForm((f) => ({ ...f, category: e.target.value as TaskCategory }))}
            options={CATEGORIES.map((c) => ({ value: c, label: c }))}
          />
          <Select label="Priority" value={form.priority}
            onChange={(e) => setForm((f) => ({ ...f, priority: e.target.value as TaskPriority }))}
            options={PRIORITIES.map((p) => ({ value: p, label: p }))}
          />
          <Input label="Due date (optional)" type="date" value={form.dueDate} onChange={(e) => setForm((f) => ({ ...f, dueDate: e.target.value }))} />
          <Button onClick={handleSave} loading={saving} style={{ marginTop: 8 }}>
            {editingTask ? 'Save Changes' : 'Add Task'}
          </Button>
        </div>
      </Modal>
    </AppShell>
  );
};

export default TasksPage;
