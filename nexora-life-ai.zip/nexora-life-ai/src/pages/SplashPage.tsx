import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const SplashPage: React.FC = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (loading) return;
    const timer = setTimeout(() => {
      navigate(user ? '/home' : '/auth', { replace: true });
    }, 2600);
    return () => clearTimeout(timer);
  }, [user, loading, navigate]);

  return (
    <div style={{
      position: 'fixed', inset: 0, background: '#0B0B0F',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      animation: 'fadeIn 0.5s ease',
    }}>
      {/* Glow */}
      <div style={{
        position: 'absolute', width: 300, height: 300, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(59,130,246,0.18) 0%, transparent 70%)',
        animation: 'glow 2.5s ease-in-out infinite',
        pointerEvents: 'none',
      }} />

      {/* Logo */}
      <div style={{
        width: 104, height: 104, borderRadius: 30,
        background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 52, marginBottom: 32,
        boxShadow: '0 20px 60px rgba(59,130,246,0.4)',
        animation: 'float 2s ease-in-out infinite',
        position: 'relative',
      }}>⚡</div>

      {/* Brand */}
      <div style={{ animation: 'fadeUp 0.6s ease 0.3s both', textAlign: 'center' }}>
        <h1 style={{
          fontSize: 38, fontWeight: 900, letterSpacing: -1.5,
          background: 'linear-gradient(135deg,#fff,#94A3B8)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
        }}>Nexora</h1>
        <p style={{ color: '#3B82F6', fontSize: 13, fontWeight: 600, letterSpacing: 4, textTransform: 'uppercase', marginTop: 4 }}>
          LIFE AI
        </p>
      </div>

      <p style={{ color: '#8B8B9E', fontSize: 15, marginTop: 18, animation: 'fadeUp 0.6s ease 0.7s both' }}>
        Build a Better You, Every Day
      </p>

      {/* Dots */}
      <div style={{ display: 'flex', gap: 8, marginTop: 64, animation: 'fadeUp 0.6s ease 1s both' }}>
        {[0, 1, 2].map((i) => (
          <div key={i} style={{
            width: 7, height: 7, borderRadius: '50%', background: '#3B82F6',
            animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite`,
          }} />
        ))}
      </div>
    </div>
  );
};

export default SplashPage;
