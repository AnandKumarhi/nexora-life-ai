import React, { useState } from 'react';
import AppShell from '../components/layout/AppShell';
import { Card, Modal, Input, Select, Button, EmptyState } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useHabits } from '../hooks/useHabits';
import { todayISO } from '../utils/helpers';

const ICON_OPTIONS = ['💧','🏋️','📖','🧘','😴','🚶','🥗','💊','🎯','✍️','🎵','🌿'];
const COLOR_OPTIONS = ['#3B82F6','#22C55E','#F59E0B','#8B5CF6','#EC4899','#06B6D4','#EF4444'];

const HabitsPage: React.FC = () => {
  const { user } = useAuth();
  const { habits, addHabit, incrementHabit, decrementHabit, removeHabit, seedDefaults } = useHabits(user?.uid);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', icon: '💧', target: '1', unit: 'times', color: '#3B82F6' });

  const today = todayISO();
  // Build last 5 weeks of heatmap data from habit history
  const getHeatmapData = () => {
    const cells: number[] = [];
    for (let i = 34; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const total = habits.reduce((sum, h) => {
        const entry = h.history.find(hd => hd.date === dateStr);
        return sum + (entry ? Math.min(entry.count / h.target, 1) : 0);
      }, 0);
      const avg = habits.length > 0 ? total / habits.length : 0;
      cells.push(Math.round(avg * 4)); // 0–4 intensity
    }
    return cells;
  };

  const weekDays = ['M','T','W','T','F','S','S'];
  const todayDayIndex = (new Date().getDay() + 6) % 7; // Mon=0

  const handleSave = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    await addHabit({ name: form.name, icon: form.icon, target: Number(form.target) || 1, unit: form.unit, color: form.color });
    setSaving(false);
    setModalOpen(false);
    setForm({ name: '', icon: '💧', target: '1', unit: 'times', color: '#3B82F6' });
  };

  const maxStreak = habits.length ? Math.max(...habits.map(h => h.streak), 0) : 0;

  return (
    <AppShell>
      <div style={{ padding: '52px 20px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <h2 style={{ fontSize: 28, fontWeight: 800, letterSpacing: -0.6 }}>Habits</h2>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: '#1A1A24', padding: '6px 14px', borderRadius: 100, border: '1px solid #2A2A38' }}>
              <span style={{ fontSize: 16, animation: 'float 2s ease-in-out infinite', display: 'inline-block' }}>🔥</span>
              <span style={{ fontSize: 14, fontWeight: 700 }}>{maxStreak}d</span>
            </div>
            <button onClick={() => setModalOpen(true)} style={{ width: 40, height: 40, borderRadius: 13, background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)', border: 'none', cursor: 'pointer', fontSize: 22, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
          </div>
        </div>

        {/* Weekday indicator */}
        <div style={{ display: 'flex', gap: 7, marginBottom: 24 }}>
          {weekDays.map((d, i) => (
            <div key={i} style={{ flex: 1, aspectRatio: '1', borderRadius: 11, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4, background: i === todayDayIndex ? '#3B82F6' : '#1A1A24', border: `1px solid ${i === todayDayIndex ? '#3B82F6' : '#2A2A38'}` }}>
              <span style={{ fontSize: 10, color: i === todayDayIndex ? '#fff' : '#8B8B9E', fontWeight: 600 }}>{d}</span>
              {i <= todayDayIndex && <div style={{ width: 5, height: 5, borderRadius: '50%', background: i === todayDayIndex ? '#fff' : '#22C55E' }} />}
            </div>
          ))}
        </div>

        {habits.length === 0 ? (
          <div>
            <EmptyState emoji="🌱" title="No habits yet" subtitle="Build your first habit and start your streak today"
              action={{ label: 'Add Habit', onClick: () => setModalOpen(true) }} />
            <Button variant="ghost" onClick={seedDefaults} style={{ marginTop: 12 }}>
              🚀 Quick-start with 5 popular habits
            </Button>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {habits.map((h, i) => {
              const pct = Math.min(100, Math.round((h.todayCount / h.target) * 100));
              const done = h.todayCount >= h.target;
              return (
                <Card key={h.id} className="fade-up" style={{ animationDelay: `${i * 0.07}s` }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 14 }}>
                    <div style={{ width: 48, height: 48, borderRadius: 14, flexShrink: 0, background: done ? `${h.color}20` : '#13131A', border: `1px solid ${done ? h.color : '#2A2A38'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, transition: 'all 0.3s ease' }}>
                      {h.icon}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
                        <p style={{ fontSize: 15, fontWeight: 600 }}>{h.name}</p>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                          {done && <span style={{ fontSize: 12, color: '#22C55E', fontWeight: 600 }}>✓ Done!</span>}
                          <span style={{ fontSize: 13, color: done ? h.color : '#8B8B9E', fontWeight: 600 }}>{h.todayCount}/{h.target} {h.unit}</span>
                        </div>
                      </div>
                      <div style={{ height: 6, background: '#2A2A38', borderRadius: 3, overflow: 'hidden' }}>
                        <div style={{ height: '100%', width: `${pct}%`, background: `linear-gradient(90deg,${h.color},${h.color}80)`, borderRadius: 3, transition: 'width 0.5s ease' }} />
                      </div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <button onClick={() => decrementHabit(h.id)} style={{ width: 38, height: 38, borderRadius: 11, border: '1px solid #2A2A38', background: '#13131A', color: '#8B8B9E', fontSize: 20, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>−</button>
                    <div style={{ flex: 1, textAlign: 'center' }}>
                      <span style={{ fontSize: 12, color: '#8B8B9E' }}>{pct}% · 🔥 {h.streak} day streak</span>
                    </div>
                    <button onClick={() => incrementHabit(h.id)} style={{ width: 38, height: 38, borderRadius: 11, border: 'none', background: done ? `${h.color}30` : h.color, color: '#fff', fontSize: 20, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.2s ease' }}>+</button>
                    <button onClick={() => removeHabit(h.id)} style={{ width: 38, height: 38, borderRadius: 11, border: '1px solid #2A2A38', background: '#13131A', color: '#EF4444', fontSize: 15, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>🗑</button>
                  </div>
                </Card>
              );
            })}
          </div>
        )}

        {/* Heatmap */}
        {habits.length > 0 && (
          <Card style={{ marginTop: 20 }}>
            <p style={{ fontSize: 14, fontWeight: 700, marginBottom: 14, letterSpacing: -0.3 }}>Activity Heatmap</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4 }}>
              {getHeatmapData().map((intensity, i) => (
                <div key={i} style={{ aspectRatio: '1', borderRadius: 4, transition: 'all 0.15s ease', background: intensity === 0 ? '#13131A' : intensity === 1 ? 'rgba(59,130,246,0.2)' : intensity === 2 ? 'rgba(59,130,246,0.4)' : intensity === 3 ? 'rgba(59,130,246,0.65)' : '#3B82F6', border: '1px solid #2A2A38' }} />
              ))}
            </div>
            <div style={{ display: 'flex', gap: 4, alignItems: 'center', marginTop: 10, justifyContent: 'flex-end' }}>
              <span style={{ fontSize: 10, color: '#8B8B9E' }}>Less</span>
              {[0,1,2,3,4].map(l => <div key={l} style={{ width: 10, height: 10, borderRadius: 2, background: l === 0 ? '#13131A' : `rgba(59,130,246,${l * 0.22})` }} />)}
              <span style={{ fontSize: 10, color: '#8B8B9E' }}>More</span>
            </div>
          </Card>
        )}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="New Habit">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Input placeholder="Habit name (e.g. Drink water)" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} autoFocus />
          <div>
            <p style={{ fontSize: 13, fontWeight: 500, color: '#B0B0C3', marginBottom: 8 }}>Icon</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {ICON_OPTIONS.map(ic => (
                <button key={ic} onClick={() => setForm(f => ({ ...f, icon: ic }))} style={{ width: 40, height: 40, borderRadius: 11, fontSize: 20, background: form.icon === ic ? '#3B82F620' : '#1A1A24', border: `2px solid ${form.icon === ic ? '#3B82F6' : '#2A2A38'}`, cursor: 'pointer' }}>{ic}</button>
              ))}
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Input label="Daily target" type="number" min="1" value={form.target} onChange={e => setForm(f => ({ ...f, target: e.target.value }))} />
            <Input label="Unit" placeholder="glasses, mins..." value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))} />
          </div>
          <div>
            <p style={{ fontSize: 13, fontWeight: 500, color: '#B0B0C3', marginBottom: 8 }}>Color</p>
            <div style={{ display: 'flex', gap: 10 }}>
              {COLOR_OPTIONS.map(c => (
                <button key={c} onClick={() => setForm(f => ({ ...f, color: c }))} style={{ width: 32, height: 32, borderRadius: '50%', background: c, border: `3px solid ${form.color === c ? '#fff' : 'transparent'}`, cursor: 'pointer' }} />
              ))}
            </div>
          </div>
          <Button onClick={handleSave} loading={saving} style={{ marginTop: 8 }}>Add Habit 🌱</Button>
        </div>
      </Modal>
    </AppShell>
  );
};

export default HabitsPage;
