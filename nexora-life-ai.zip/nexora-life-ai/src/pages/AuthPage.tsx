import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Input } from '../components/ui';
import { signInWithEmail, signUpWithEmail, signInWithGoogle, resetPassword } from '../services/authService';
import { useToast } from '../contexts/ToastContext';

type Mode = 'login' | 'signup' | 'forgot';

const AuthPage: React.FC = () => {
  const [mode, setMode] = useState<Mode>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return toast('Please enter your email', 'error');
    if (mode !== 'forgot' && !password) return toast('Please enter your password', 'error');
    if (mode === 'signup' && !name) return toast('Please enter your name', 'error');

    setLoading(true);
    try {
      if (mode === 'login') {
        await signInWithEmail(email, password);
        navigate('/home');
      } else if (mode === 'signup') {
        await signUpWithEmail(email, password, name);
        navigate('/home');
      } else {
        await resetPassword(email);
        toast('Reset link sent! Check your inbox. 📬');
        setMode('login');
      }
    } catch (err: any) {
      const msg = err?.code === 'auth/wrong-password' ? 'Incorrect password'
        : err?.code === 'auth/user-not-found' ? 'No account with that email'
        : err?.code === 'auth/email-already-in-use' ? 'Email already in use'
        : err?.code === 'auth/weak-password' ? 'Password must be at least 6 characters'
        : 'Something went wrong. Try again.';
      toast(msg, 'error');
    }
    setLoading(false);
  };

  const handleGoogle = async () => {
    setGoogleLoading(true);
    try {
      await signInWithGoogle();
      navigate('/home');
    } catch {
      toast('Google sign-in failed. Try again.', 'error');
    }
    setGoogleLoading(false);
  };

  return (
    <div style={{
      maxWidth: 430, margin: '0 auto', minHeight: '100vh',
      background: '#0B0B0F', padding: '60px 28px 40px',
      display: 'flex', flexDirection: 'column',
    }}>
      {/* Logo */}
      <div className="fade-up" style={{ marginBottom: 40 }}>
        <div style={{
          width: 56, height: 56, borderRadius: 18,
          background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 28, marginBottom: 22,
          boxShadow: '0 8px 32px rgba(59,130,246,0.35)',
          animation: 'float 3s ease-in-out infinite',
        }}>⚡</div>
        <h1 style={{ fontSize: 30, fontWeight: 800, letterSpacing: -0.8, marginBottom: 8 }}>
          {mode === 'login' ? 'Welcome back' : mode === 'signup' ? 'Create account' : 'Reset password'}
        </h1>
        <p style={{ color: '#8B8B9E', fontSize: 15, lineHeight: 1.5 }}>
          {mode === 'login' ? 'Sign in to continue your journey'
            : mode === 'signup' ? 'Start building better habits today'
            : "We'll send you a reset link right away"}
        </p>
      </div>

      {/* Form */}
      <form
        onSubmit={handleSubmit}
        style={{ display: 'flex', flexDirection: 'column', gap: 14 }}
        className="fade-up"
      >
        {mode === 'signup' && (
          <Input placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
        )}
        <Input placeholder="Email address" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        {mode !== 'forgot' && (
          <Input placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} />
        )}

        {mode === 'login' && (
          <button
            type="button"
            onClick={() => setMode('forgot')}
            style={{ background: 'none', border: 'none', color: '#3B82F6', fontSize: 14, fontWeight: 500, cursor: 'pointer', textAlign: 'right', fontFamily: 'Inter,sans-serif' }}
          >
            Forgot password?
          </button>
        )}

        <Button type="submit" loading={loading} style={{ marginTop: 4 }}>
          {mode === 'login' ? 'Sign In' : mode === 'signup' ? 'Create Account' : 'Send Reset Link'}
        </Button>

        {mode !== 'forgot' && (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '4px 0' }}>
              <div style={{ flex: 1, height: 1, background: '#2A2A38' }} />
              <span style={{ color: '#8B8B9E', fontSize: 13 }}>or</span>
              <div style={{ flex: 1, height: 1, background: '#2A2A38' }} />
            </div>
            <Button variant="ghost" type="button" onClick={handleGoogle} loading={googleLoading}>
              <span style={{ fontSize: 18 }}>🔵</span> Continue with Google
            </Button>
          </>
        )}

        <p style={{ textAlign: 'center', color: '#8B8B9E', fontSize: 14, marginTop: 8 }}>
          {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
          <button
            type="button"
            onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
            style={{ background: 'none', border: 'none', color: '#3B82F6', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'Inter,sans-serif' }}
          >
            {mode === 'login' ? 'Sign up' : 'Sign in'}
          </button>
        </p>
      </form>
    </div>
  );
};

export default AuthPage;
