import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import AppShell from '../components/layout/AppShell';
import { Card, ProgressCircle } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useTasks } from '../hooks/useTasks';
import { useGoals } from '../hooks/useGoals';
import { useHabits } from '../hooks/useHabits';
import { getPriorityColor, getGreeting, formatDate, getRandomQuote } from '../utils/helpers';

const HomePage: React.FC = () => {
  const { user } = useAuth();
  const { tasks, toggleTask } = useTasks(user?.uid);
  const { goals } = useGoals(user?.uid);
  const { habits } = useHabits(user?.uid);
  const navigate = useNavigate();

  const displayName = user?.displayName?.split(' ')[0] ?? 'there';
  const quote = useMemo(getRandomQuote, []);

  const totalTasks = tasks.length;
  const doneTasks = tasks.filter((t) => t.done).length;
  const progress = totalTasks ? Math.round((doneTasks / totalTasks) * 100) : 0;
  const pendingTasks = tasks.filter((t) => !t.done).slice(0, 4);
  const maxStreak = habits.length ? Math.max(...habits.map((h) => h.streak), 0) : 0;

  return (
    <AppShell>
      {/* Header hero */}
      <div style={{
        padding: '52px 24px 24px',
        background: 'linear-gradient(180deg, rgba(59,130,246,0.07) 0%, transparent 100%)',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: -80, right: -80, width: 240, height: 240,
          borderRadius: '50%', background: 'radial-gradient(circle, rgba(59,130,246,0.1) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div className="fade-up">
          <p style={{ color: '#8B8B9E', fontSize: 13, marginBottom: 4 }}>{formatDate()}</p>
          <h1 style={{ fontSize: 28, fontWeight: 800, letterSpacing: -0.6, lineHeight: 1.2, marginBottom: 6 }}>
            {getGreeting()},<br />
            <span className="gradient-text">{displayName} 👋</span>
          </h1>
          <p style={{ color: '#8B8B9E', fontSize: 14 }}>
            {doneTasks} of {totalTasks} tasks done · Keep crushing it!
          </p>
        </div>
      </div>

      <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        {/* Progress + Streak */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Card className="fade-up" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, padding: '20px 16px' }}>
            <ProgressCircle pct={progress} label={`${progress}%`} sublabel="Done" />
            <p style={{ color: '#8B8B9E', fontSize: 12, fontWeight: 500 }}>Daily Progress</p>
          </Card>
          <Card className="fade-up" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, padding: '20px 16px' }}>
            <span style={{ fontSize: 36, animation: 'float 2.5s ease-in-out infinite', display: 'inline-block' }}>🔥</span>
            <p style={{ fontSize: 28, fontWeight: 800, letterSpacing: -1 }}>{maxStreak}</p>
            <p style={{ color: '#8B8B9E', fontSize: 12, fontWeight: 500 }}>Day Streak</p>
          </Card>
        </div>

        {/* AI Quote */}
        <div className="fade-up" style={{
          background: 'linear-gradient(135deg, rgba(59,130,246,0.12), rgba(139,92,246,0.12))',
          borderRadius: 20, padding: '18px 20px',
          border: '1px solid rgba(59,130,246,0.2)',
        }}>
          <div style={{ display: 'flex', gap: 12 }}>
            <div style={{
              width: 34, height: 34, borderRadius: 11, flexShrink: 0,
              background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17,
            }}>✨</div>
            <div>
              <p style={{ fontSize: 11, color: '#3B82F6', fontWeight: 600, marginBottom: 5, letterSpacing: 1, textTransform: 'uppercase' }}>Daily Insight</p>
              <p style={{ fontSize: 14, lineHeight: 1.65, color: '#B0B0C3', letterSpacing: -0.2 }}>"{quote}"</p>
            </div>
          </div>
        </div>

        {/* Today's Tasks */}
        <div className="fade-up">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 style={{ fontSize: 17, fontWeight: 700, letterSpacing: -0.3 }}>Today's Tasks</h3>
            <button
              onClick={() => navigate('/tasks')}
              style={{ background: 'none', border: 'none', color: '#3B82F6', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'Inter,sans-serif' }}
            >
              + Add
            </button>
          </div>

          {pendingTasks.length === 0 ? (
            <Card style={{ textAlign: 'center', padding: '28px 20px' }}>
              <p style={{ fontSize: 28, marginBottom: 8 }}>🎉</p>
              <p style={{ color: '#8B8B9E', fontSize: 14 }}>All tasks done! Great work today.</p>
            </Card>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {pendingTasks.map((t, i) => (
                <Card key={t.id} style={{
                  padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 14,
                  animationDelay: `${i * 0.07}s`,
                }} className="fade-up">
                  <button
                    onClick={() => toggleTask(t.id)}
                    style={{
                      width: 27, height: 27, borderRadius: 8, flexShrink: 0,
                      border: `2px solid ${t.done ? '#3B82F6' : '#2A2A38'}`,
                      background: t.done ? '#3B82F6' : 'transparent',
                      cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                      transition: 'all 0.25s cubic-bezier(0.34,1.56,0.64,1)', fontSize: 13,
                    }}
                  >
                    {t.done ? '✓' : ''}
                  </button>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 14, fontWeight: 500, marginBottom: 3, textDecoration: t.done ? 'line-through' : 'none', opacity: t.done ? 0.5 : 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {t.title}
                    </p>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={{ fontSize: 11, color: '#8B8B9E' }}>{t.category}</span>
                      {t.priority === 'High' && (
                        <span style={{ fontSize: 10, fontWeight: 600, color: getPriorityColor(t.priority), background: `${getPriorityColor(t.priority)}20`, padding: '2px 7px', borderRadius: 100 }}>
                          ● High
                        </span>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
              {tasks.filter((t) => !t.done).length > 4 && (
                <button
                  onClick={() => navigate('/tasks')}
                  style={{ background: 'none', border: 'none', color: '#3B82F6', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'Inter,sans-serif', padding: '4px 0', textAlign: 'center' }}
                >
                  View all {tasks.filter((t) => !t.done).length} tasks →
                </button>
              )}
            </div>
          )}
        </div>

        {/* Habits preview */}
        {habits.length > 0 && (
          <div className="fade-up">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h3 style={{ fontSize: 17, fontWeight: 700, letterSpacing: -0.3 }}>Habits</h3>
              <button onClick={() => navigate('/goals')} style={{ background: 'none', border: 'none', color: '#3B82F6', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'Inter,sans-serif' }}>See all</button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: `repeat(${Math.min(habits.length, 3)}, 1fr)`, gap: 10 }}>
              {habits.slice(0, 3).map((h) => {
                const pct = Math.min(100, Math.round((h.todayCount / h.target) * 100));
                return (
                  <Card key={h.id} style={{ padding: '14px 10px', textAlign: 'center' }}>
                    <p style={{ fontSize: 22, marginBottom: 5 }}>{h.icon}</p>
                    <p style={{ fontSize: 12, fontWeight: 600, marginBottom: 4 }}>{h.name}</p>
                    <p style={{ fontSize: 10, color: pct >= 100 ? '#22C55E' : '#8B8B9E' }}>{pct}%</p>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Goals preview */}
        {goals.length > 0 && (
          <div className="fade-up">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h3 style={{ fontSize: 17, fontWeight: 700, letterSpacing: -0.3 }}>Active Goals</h3>
              <button onClick={() => navigate('/goals')} style={{ background: 'none', border: 'none', color: '#3B82F6', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'Inter,sans-serif' }}>See all</button>
            </div>
            <Card>
              {goals.slice(0, 2).map((g, i) => (
                <div key={g.id} style={{ marginBottom: i < Math.min(goals.length, 2) - 1 ? 16 : 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 7 }}>
                    <span style={{ fontSize: 13, fontWeight: 600 }}>{g.title}</span>
                    <span style={{ fontSize: 12, color: '#3B82F6', fontWeight: 700 }}>{g.progress}%</span>
                  </div>
                  <div style={{ height: 6, background: '#2A2A38', borderRadius: 3, overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${g.progress}%`, background: 'linear-gradient(90deg,#3B82F6,#8B5CF6)', borderRadius: 3, transition: 'width 1s ease' }} />
                  </div>
                </div>
              ))}
            </Card>
          </div>
        )}
      </div>

      {/* FAB */}
      <button
        onClick={() => navigate('/tasks')}
        style={{
          position: 'fixed', bottom: 100, right: 24,
          width: 56, height: 56, borderRadius: 18,
          background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)',
          border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 26, boxShadow: '0 8px 32px rgba(59,130,246,0.45)',
          animation: 'glow 3s ease-in-out infinite',
          zIndex: 50, transition: 'transform 0.2s ease',
        }}
        onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.08)')}
        onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
      >+</button>
    </AppShell>
  );
};

export default HomePage;
