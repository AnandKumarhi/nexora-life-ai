import React, { useRef, useEffect, useState } from 'react';
import AppShell from '../components/layout/AppShell';
import { useAuth } from '../contexts/AuthContext';
import { useChat } from '../hooks/useChat';

const SUGGESTED = [
  { label: 'Plan my day', icon: '🗓️' },
  { label: 'Motivate me', icon: '⚡' },
  { label: 'Improve discipline', icon: '💪' },
  { label: 'Build habits', icon: '🌱' },
  { label: 'Beat procrastination', icon: '🎯' },
  { label: 'Evening reflection', icon: '🌙' },
];

const CoachPage: React.FC = () => {
  const { user } = useAuth();
  const displayName = user?.displayName ?? 'there';
  const { messages, streaming, sendMessage, clearHistory } = useChat(user?.uid ?? '', displayName);
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streaming]);

  const handleSend = async (text = input) => {
    if (!text.trim() || streaming) return;
    setInput('');
    await sendMessage(text);
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  return (
    <div style={{ maxWidth: 430, margin: '0 auto', height: '100vh', display: 'flex', flexDirection: 'column', background: '#0B0B0F' }}>
      {/* Header */}
      <div style={{ padding: '52px 22px 16px', background: 'linear-gradient(180deg,rgba(59,130,246,0.07) 0%,transparent 100%)', borderBottom: '1px solid #2A2A38', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
            <div style={{ width: 46, height: 46, borderRadius: 14, background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>🤖</div>
            <div>
              <p style={{ fontSize: 17, fontWeight: 700, letterSpacing: -0.3 }}>Nexora AI Coach</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#22C55E', animation: 'pulse 2s infinite' }} />
                <span style={{ fontSize: 12, color: '#8B8B9E' }}>Online · GPT-4o powered</span>
              </div>
            </div>
          </div>
          <button onClick={clearHistory} style={{ background: '#1A1A24', border: '1px solid #2A2A38', borderRadius: 10, padding: '7px 12px', cursor: 'pointer', color: '#8B8B9E', fontSize: 12, fontFamily: 'Inter,sans-serif' }}>
            Clear
          </button>
        </div>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '18px 16px' }}>
        {messages.length === 1 && (
          <div style={{ marginBottom: 20 }}>
            <p style={{ color: '#8B8B9E', fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 12 }}>Quick Prompts</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {SUGGESTED.map(p => (
                <button key={p.label} onClick={() => handleSend(p.label)} style={{ background: '#1A1A24', border: '1px solid #2A2A38', borderRadius: 14, padding: '12px 14px', cursor: 'pointer', color: '#fff', textAlign: 'left', transition: 'all 0.2s ease', fontFamily: 'Inter,sans-serif' }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = '#3B82F6'; e.currentTarget.style.background = 'rgba(59,130,246,0.08)'; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = '#2A2A38'; e.currentTarget.style.background = '#1A1A24'; }}>
                  <span style={{ fontSize: 18, display: 'block', marginBottom: 4 }}>{p.icon}</span>
                  <span style={{ fontSize: 13, fontWeight: 500 }}>{p.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map(m => (
          <div key={m.id} style={{ display: 'flex', justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start', marginBottom: 14, animation: 'fadeUp 0.3s ease' }}>
            {m.role === 'assistant' && (
              <div style={{ width: 30, height: 30, borderRadius: 10, marginRight: 8, flexShrink: 0, background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14 }}>⚡</div>
            )}
            <div style={{ maxWidth: '78%', background: m.role === 'user' ? 'linear-gradient(135deg,#3B82F6,#2563EB)' : '#1A1A24', borderRadius: m.role === 'user' ? '18px 18px 6px 18px' : '18px 18px 18px 6px', padding: '12px 16px', border: m.role === 'assistant' ? '1px solid #2A2A38' : 'none' }}>
              <p style={{ fontSize: 14, lineHeight: 1.65, letterSpacing: -0.2, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{m.content}</p>
              <p style={{ fontSize: 10, color: m.role === 'user' ? 'rgba(255,255,255,0.45)' : '#8B8B9E', marginTop: 4 }}>
                {new Date(m.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}

        {streaming && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
            <div style={{ width: 30, height: 30, borderRadius: 10, background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, flexShrink: 0 }}>⚡</div>
            <div style={{ background: '#1A1A24', border: '1px solid #2A2A38', borderRadius: '18px 18px 18px 6px', padding: '14px 18px', display: 'flex', gap: 6, alignItems: 'center' }}>
              {[0,1,2].map(i => <div key={i} style={{ width: 7, height: 7, background: '#3B82F6', borderRadius: '50%', animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite` }} />)}
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input bar */}
      <div style={{ padding: '12px 16px 28px', borderTop: '1px solid #2A2A38', background: '#13131A', flexShrink: 0 }}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
          <textarea ref={inputRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey} placeholder="Ask your AI coach..."
            rows={1} style={{ flex: 1, background: '#1A1A24', border: '1px solid #2A2A38', borderRadius: 14, padding: '13px 16px', fontSize: 14, color: '#fff', fontFamily: 'Inter,sans-serif', outline: 'none', resize: 'none', lineHeight: 1.5 }}
            onFocus={e => { e.currentTarget.style.borderColor = '#3B82F6'; }}
            onBlur={e => { e.currentTarget.style.borderColor = '#2A2A38'; }}
          />
          <button onClick={() => handleSend()} disabled={!input.trim() || streaming} style={{ width: 46, height: 46, borderRadius: 14, flexShrink: 0, background: input.trim() && !streaming ? 'linear-gradient(135deg,#3B82F6,#2563EB)' : '#1A1A24', border: `1px solid ${input.trim() && !streaming ? 'transparent' : '#2A2A38'}`, cursor: input.trim() && !streaming ? 'pointer' : 'default', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, transition: 'all 0.2s ease' }}>
            {streaming ? <span style={{ animation: 'spin 1s linear infinite', display: 'inline-block' }}>⟳</span> : '↑'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CoachPage;
