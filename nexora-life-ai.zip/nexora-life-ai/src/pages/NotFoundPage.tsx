import React from 'react';
import { useNavigate } from 'react-router-dom';

const NotFoundPage: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div style={{ maxWidth: 430, margin: '0 auto', minHeight: '100vh', background: '#0B0B0F', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 32, textAlign: 'center' }}>
      <p style={{ fontSize: 64, marginBottom: 16 }}>🌌</p>
      <h1 style={{ fontSize: 28, fontWeight: 800, marginBottom: 8 }}>Lost in space</h1>
      <p style={{ color: '#8B8B9E', fontSize: 15, marginBottom: 32, lineHeight: 1.6 }}>This page doesn't exist. Let's get you back on track.</p>
      <button onClick={() => navigate('/home', { replace: true })} style={{ background: 'linear-gradient(135deg,#3B82F6,#2563EB)', color: '#fff', border: 'none', borderRadius: 14, padding: '14px 28px', fontSize: 15, fontWeight: 600, cursor: 'pointer', fontFamily: 'Inter,sans-serif' }}>
        Back to Home
      </button>
    </div>
  );
};

export default NotFoundPage;
