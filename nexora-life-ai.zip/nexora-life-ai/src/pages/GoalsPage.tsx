import React, { useState } from 'react';
import AppShell from '../components/layout/AppShell';
import { Card, Button, Input, Textarea, Modal, EmptyState, ProgressCircle } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useGoals } from '../hooks/useGoals';
import { Goal } from '../utils/types';
import { getDaysUntil, getGoalColor } from '../utils/helpers';

const GoalsPage: React.FC = () => {
  const { user } = useAuth();
  const { goals, addGoal, updateProgress, toggleMilestone, removeGoal } = useGoals(user?.uid);

  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', deadline: '', milestoneTexts: '' });

  const handleSave = async () => {
    if (!form.title.trim()) return;
    setSaving(true);
    await addGoal({
      title: form.title,
      description: form.description,
      deadline: form.deadline,
      milestoneTexts: form.milestoneTexts.split(',').map(s => s.trim()).filter(Boolean),
    });
    setSaving(false);
    setModalOpen(false);
    setForm({ title: '', description: '', deadline: '', milestoneTexts: '' });
  };

  return (
    <AppShell>
      <div style={{ padding: '52px 20px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <h2 style={{ fontSize: 28, fontWeight: 800, letterSpacing: -0.6 }}>Goals</h2>
          <button onClick={() => setModalOpen(true)} style={{
            width: 40, height: 40, borderRadius: 13,
            background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)',
            border: 'none', cursor: 'pointer', fontSize: 22,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>+</button>
        </div>

        {goals.length === 0 ? (
          <EmptyState emoji="🎯" title="No goals yet" subtitle="Set your first goal and start making progress every day"
            action={{ label: 'Create Goal', onClick: () => setModalOpen(true) }} />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {goals.map((g, i) => {
              const color = getGoalColor(i);
              const daysLeft = g.deadline ? getDaysUntil(g.deadline) : null;
              return (
                <Card key={g.id} className="fade-up" style={{ border: `1px solid ${color}28`, animationDelay: `${i * 0.08}s` }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
                    <div style={{ flex: 1, paddingRight: 12 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                        <div style={{ width: 9, height: 9, borderRadius: '50%', background: color, flexShrink: 0 }} />
                        <h3 style={{ fontSize: 16, fontWeight: 700, letterSpacing: -0.3 }}>{g.title}</h3>
                      </div>
                      {g.description && <p style={{ color: '#8B8B9E', fontSize: 13, marginLeft: 17, lineHeight: 1.5 }}>{g.description}</p>}
                      {daysLeft !== null && (
                        <p style={{ color: daysLeft < 7 ? '#EF4444' : '#8B8B9E', fontSize: 12, marginLeft: 17, marginTop: 4 }}>
                          {daysLeft > 0 ? `⏳ ${daysLeft} days left` : '⚠️ Deadline passed'}
                        </p>
                      )}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <ProgressCircle pct={g.progress} size={58} stroke={5} color={color} label={`${g.progress}%`} />
                      <button onClick={() => removeGoal(g.id)} style={{ padding: 6, background: 'none', border: 'none', cursor: 'pointer', color: '#EF4444', fontSize: 15 }}>🗑</button>
                    </div>
                  </div>

                  <div style={{ height: 7, background: '#2A2A38', borderRadius: 4, overflow: 'hidden', marginBottom: 14 }}>
                    <div style={{ height: '100%', width: `${g.progress}%`, background: `linear-gradient(90deg,${color},${color}80)`, borderRadius: 4, transition: 'width 0.7s ease' }} />
                  </div>

                  <div style={{ display: 'flex', gap: 8, marginBottom: g.milestones.length > 0 ? 16 : 0 }}>
                    {[-10, -5, +5, +10].map(d => (
                      <button key={d} onClick={() => updateProgress(g.id, d)} style={{
                        flex: 1, padding: '9px 0', borderRadius: 10, fontSize: 12, fontWeight: 600,
                        background: d > 0 ? `${color}18` : '#13131A',
                        border: `1px solid ${d > 0 ? color + '40' : '#2A2A38'}`,
                        color: d > 0 ? color : '#8B8B9E',
                        cursor: 'pointer', fontFamily: 'Inter,sans-serif', transition: 'all 0.15s ease',
                      }}>{d > 0 ? '+' : ''}{d}%</button>
                    ))}
                  </div>

                  {g.milestones.length > 0 && (
                    <div style={{ borderTop: '1px solid #2A2A38', paddingTop: 14 }}>
                      <p style={{ fontSize: 11, color: '#8B8B9E', fontWeight: 600, marginBottom: 10, textTransform: 'uppercase', letterSpacing: 0.7 }}>Milestones</p>
                      {g.milestones.map(m => (
                        <div key={m.id} onClick={() => toggleMilestone(g.id, m.id)}
                          style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8, cursor: 'pointer' }}>
                          <div style={{
                            width: 19, height: 19, borderRadius: 6, flexShrink: 0,
                            background: m.done ? color : 'transparent',
                            border: `2px solid ${m.done ? color : '#2A2A38'}`,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            fontSize: 11, transition: 'all 0.2s ease',
                          }}>{m.done ? '✓' : ''}</div>
                          <span style={{ fontSize: 13, color: m.done ? '#8B8B9E' : '#fff', textDecoration: m.done ? 'line-through' : 'none' }}>{m.text}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="New Goal">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Input placeholder="Goal title (e.g. Run a 5K)" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} autoFocus />
          <Textarea placeholder="Description (optional)" rows={2} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
          <Input label="Deadline (optional)" type="date" value={form.deadline} onChange={e => setForm(f => ({ ...f, deadline: e.target.value }))} />
          <Input placeholder="Milestones, comma separated" value={form.milestoneTexts} onChange={e => setForm(f => ({ ...f, milestoneTexts: e.target.value }))} />
          <Button onClick={handleSave} loading={saving} style={{ marginTop: 8 }}>Create Goal 🎯</Button>
        </div>
      </Modal>
    </AppShell>
  );
};

export default GoalsPage;
