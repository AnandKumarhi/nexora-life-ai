import React, { useState } from 'react';
import AppShell from '../components/layout/AppShell';
import { Card, Button, Toggle } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useTasks } from '../hooks/useTasks';
import { useHabits } from '../hooks/useHabits';
import { useGoals } from '../hooks/useGoals';
import { signOutUser } from '../services/authService';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../contexts/ToastContext';

const ACHIEVEMENTS = [
  { icon: '🔥', label: '7-Day Streak', desc: 'Consistent champion' },
  { icon: '✅', label: 'Task Master', desc: '10+ tasks completed' },
  { icon: '⚡', label: 'Goal Setter', desc: 'First goal created' },
  { icon: '🌱', label: 'Habit Builder', desc: 'First habit tracked' },
];

const ProfilePage: React.FC = () => {
  const { user } = useAuth();
  const { tasks } = useTasks(user?.uid);
  const { habits } = useHabits(user?.uid);
  const { goals } = useGoals(user?.uid);
  const navigate = useNavigate();
  const { toast } = useToast();

  const [notifications, setNotifications] = useState(true);
  const [signingOut, setSigningOut] = useState(false);

  const displayName = user?.displayName ?? 'User';
  const initials = displayName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
  const doneTasks = tasks.filter(t => t.done).length;
  const maxStreak = habits.length ? Math.max(...habits.map(h => h.streak), 0) : 0;
  const productivityScore = Math.min(999, doneTasks * 12 + maxStreak * 15 + goals.length * 30);

  const handleSignOut = async () => {
    setSigningOut(true);
    try {
      await signOutUser();
      navigate('/auth', { replace: true });
    } catch {
      toast('Sign out failed. Try again.', 'error');
    }
    setSigningOut(false);
  };

  const stats = [
    { label: 'Completed', val: doneTasks, icon: '✅' },
    { label: 'Streak', val: `${maxStreak}d`, icon: '🔥' },
    { label: 'Score', val: productivityScore, icon: '⚡' },
  ];

  const SETTINGS_ITEMS = [
    { icon: '🌙', label: 'Dark Mode', sublabel: 'Always on', right: <Toggle checked={true} onChange={() => {}} /> },
    { icon: '🔔', label: 'Notifications', sublabel: 'Push alerts', right: <Toggle checked={notifications} onChange={setNotifications} /> },
    { icon: '🎯', label: 'Goals', sublabel: `${goals.length} active`, right: <span style={{ color: '#8B8B9E', fontSize: 16 }}>›</span>, onClick: () => navigate('/goals') },
    { icon: '📊', label: 'Analytics', sublabel: 'View insights', right: <span style={{ color: '#8B8B9E', fontSize: 16 }}>›</span> },
  ];

  return (
    <AppShell>
      {/* Hero */}
      <div style={{ padding: '52px 24px 28px', background: 'linear-gradient(180deg,rgba(59,130,246,0.07) 0%,transparent 100%)', textAlign: 'center' }}>
        <div style={{ width: 90, height: 90, borderRadius: 28, background: 'linear-gradient(135deg,#3B82F6,#8B5CF6)', margin: '0 auto 16px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 34, fontWeight: 800, boxShadow: '0 12px 40px rgba(59,130,246,0.35)', animation: 'float 3s ease-in-out infinite' }}>
          {user?.photoURL ? <img src={user.photoURL} alt="avatar" style={{ width: '100%', height: '100%', borderRadius: 28, objectFit: 'cover' }} /> : initials}
        </div>
        <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: -0.5, marginBottom: 4 }}>{displayName}</h2>
        <p style={{ color: '#8B8B9E', fontSize: 14, marginBottom: 22 }}>{user?.email}</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10 }}>
          {stats.map(s => (
            <Card key={s.label} style={{ padding: '14px 8px', textAlign: 'center' }}>
              <p style={{ fontSize: 20, marginBottom: 4 }}>{s.icon}</p>
              <p style={{ fontSize: 20, fontWeight: 800 }}>{s.val}</p>
              <p style={{ fontSize: 11, color: '#8B8B9E' }}>{s.label}</p>
            </Card>
          ))}
        </div>
      </div>

      <div style={{ padding: '0 20px 20px' }}>
        {/* Achievements */}
        <div style={{ marginBottom: 24 }}>
          <p style={{ fontSize: 16, fontWeight: 700, marginBottom: 14, letterSpacing: -0.3 }}>Achievements</p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {ACHIEVEMENTS.map((a, i) => (
              <Card key={i} className="fade-up" style={{ background: 'linear-gradient(135deg,rgba(59,130,246,0.1),rgba(139,92,246,0.1))', border: '1px solid rgba(59,130,246,0.2)', padding: '16px', animationDelay: `${i * 0.06}s` }}>
                <p style={{ fontSize: 26, marginBottom: 7 }}>{a.icon}</p>
                <p style={{ fontSize: 13, fontWeight: 600, marginBottom: 3 }}>{a.label}</p>
                <p style={{ fontSize: 11, color: '#8B8B9E' }}>{a.desc}</p>
              </Card>
            ))}
          </div>
        </div>

        {/* Settings */}
        <div style={{ marginBottom: 24 }}>
          <p style={{ fontSize: 16, fontWeight: 700, marginBottom: 14, letterSpacing: -0.3 }}>Settings</p>
          <Card style={{ padding: 0, overflow: 'hidden' }}>
            {SETTINGS_ITEMS.map((item, i) => (
              <div key={i} onClick={item.onClick} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '16px 18px', borderBottom: i < SETTINGS_ITEMS.length - 1 ? '1px solid #2A2A38' : 'none', cursor: item.onClick ? 'pointer' : 'default' }}>
                <span style={{ fontSize: 20 }}>{item.icon}</span>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 14, fontWeight: 500 }}>{item.label}</p>
                  <p style={{ fontSize: 12, color: '#8B8B9E' }}>{item.sublabel}</p>
                </div>
                {item.right}
              </div>
            ))}
          </Card>
        </div>

        <Button variant="danger" onClick={handleSignOut} loading={signingOut}>
          🚪 Sign Out
        </Button>

        <p style={{ textAlign: 'center', color: '#2A2A38', fontSize: 12, marginTop: 24 }}>
          Nexora Life AI · v1.0.0
        </p>
      </div>
    </AppShell>
  );
};

export default ProfilePage;
