// ─── User ──────────────────────────────────────────────────────────
export interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL?: string | null;
}

// ─── Task ──────────────────────────────────────────────────────────
export type TaskPriority = 'High' | 'Medium' | 'Low';
export type TaskCategory = 'Work' | 'Health' | 'Personal' | 'Learning' | 'Finance';

export interface Task {
  id: string;
  userId: string;
  title: string;
  category: TaskCategory;
  priority: TaskPriority;
  dueDate: string;
  done: boolean;
  createdAt: string;
  updatedAt: string;
}

// ─── Goal ──────────────────────────────────────────────────────────
export interface Milestone {
  id: string;
  text: string;
  done: boolean;
}

export interface Goal {
  id: string;
  userId: string;
  title: string;
  description: string;
  deadline: string;
  progress: number;
  milestones: Milestone[];
  createdAt: string;
  updatedAt: string;
}

// ─── Habit ─────────────────────────────────────────────────────────
export interface HabitDay {
  date: string; // YYYY-MM-DD
  count: number;
}

export interface Habit {
  id: string;
  userId: string;
  name: string;
  icon: string;
  target: number;
  unit: string;
  color: string;
  todayCount: number;
  streak: number;
  history: HabitDay[];
  createdAt: string;
  updatedAt: string;
}

// ─── Chat ──────────────────────────────────────────────────────────
export type MessageRole = 'user' | 'assistant';

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: string;
}

// ─── UI State ──────────────────────────────────────────────────────
export type AppTab = 'home' | 'coach' | 'tasks' | 'goals' | 'profile';
export type AuthMode = 'login' | 'signup' | 'forgot';

export interface ToastOptions {
  id?: string;
  message: string;
  type?: 'success' | 'error' | 'info';
  duration?: number;
}
